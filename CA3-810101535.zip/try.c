#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define true 1
#define false 0
#include "header.h"

int main(){
    user* head = (user*)malloc(sizeof(user));
    user* current_user = (user*)malloc(sizeof(user));
    post* head_post = (post*)malloc(sizeof(post));
    like_user* head_like = (like_user*)malloc(sizeof(like_user));
    current_user=NULL;
    head = NULL;
    head_post = NULL;
    head_like = NULL;
    while(true){
    printf("What do you want to do ?\n");
   
    int  a = 0;
    int x = 1;
    char* action;
    action = (char*)malloc(1);
    fflush(stdin);
    while(1){
        char character;
        scanf("%c",&character);

        if(character=='\n' || (int)character<32 || (int)character>126 || character==' '){
            action[x-1]='\0';
            break;
        }
        action[a]=character;
        x+=1;
        a+=1;
        action = (char*)realloc(action,x*sizeof(char));
        action[x-1]='\0';
    }
   /*action numbers:
        signup 0
        login 1
        post 2
        like 3
        logout 4
        delete 5
        info 6
        find_user 7*/
       
    switch (user_action(action))
    {

    case 0:{
    char* name = (char*)malloc(1);/*you cant free these. even after putting them in the linked list(result of a test!)*/
    char* password=(char*)malloc(1); 
    a=0;x=1;
    char character;
    while(true){
        scanf("%c",&character);
        if(character=='\n' || character==' '){
            name[x-1]='\0';
            break;
        }
        name[a]=character;
        x+=1;
        a+=1;
        name = (char*)realloc(name,x*sizeof(char));
        name[x-1]='\0';
    }
    a=0;x=1;
    char ch;
    while(true){
        scanf("%c",&ch);
        if(ch=='\n' || ch==' '){
            password[x-1]='\0';
            break;
        }
        password[a]=ch;
        x+=1;
        a+=1;
        password = (char*)realloc(password,x*sizeof(char));
        password[x-1]='\0';
    }

   user* temp = (user*)malloc(sizeof(user));
   int dummy = 0;
   if (head!=NULL){
        temp = head;
        while(temp!=NULL){
        if(strcmp (name,temp->username)==0){
            dummy+=1;
        }
        temp=temp->next;
   }
   }
   if(dummy==0){
    head=fsignup(name,password,head);
    printf("you are now signed in. for starting your journey login.\n");
    }
    else
       printf("someone has chosen this username before you. think of another one.\n");
    free(action);
        break;}


    case 1:{
        if (current_user != NULL){
            printf("you are already logged in as %s!\n",current_user->username);
            free(action);
            break;}
    char* name_log = (char*)malloc(1);
    char* password_log=(char*)malloc(1); 
    scanf("%s %s",name_log,password_log);
    current_user = flogin(name_log,password_log,head,current_user);
    free(action);
        break;}


    case 2:{
        if (current_user==NULL){
            printf("you have to login first\n");
            free(action);
            break;}
        int  a = 0;int x = 1;
    char* content;
    content = (char*)malloc(1);
    while(1){
        char character;
        scanf("%c",&character);
        if(character=='\n'){
            content[x-1]='\0';
            break;}
        content[a]=character;
        x+=1;a+=1;
        content = (char*)realloc(content,x*sizeof(char));
        content[x-1]='\0';}
    if(head_post==NULL){
        head_post=fpost(current_user,head_post,content);}
        else{
        fpost(current_user,head_post,content);}
        printf("your post is uploaded\n");
       free(action);
        break;}


    case 3:{
        a=0;x=1;
        if (current_user==NULL){
            printf("you have to login first\n");
            free(action);
            break;}
        int num;
        char* name = (char*)malloc(1);
        char character;
        while(true){
            scanf("%c",&character);
             if(character=='\n' || character==' '){
                     break;}
            name[a]=character;
            a+=1;x+=1;
            name=(char*)realloc(name,x);
            name[x-1]='\0';}
            
        a=0;x=1;
        num = (int)malloc(4);
            scanf("%d",&num);
        if(flike_user(head_like,current_user->username,num)==NULL && head_like!=NULL){
            printf("you have liked this post before.\n");
            break;}    
        if(head_like==NULL){
            head_like = flike_user(head_like,current_user->username,num);
            }
        flike(head_post,name,num);
        free(action);
        break;}

    case 4:{/*works fine*/
        if (current_user==NULL){
            printf("you have to login first\n");
            free(action);
            break;}
        current_user = flogout(current_user);
        printf("you are now logged out!\n");
        free(action);
        break;}
    
    
    case 5:{
    int num;
    scanf("%d",&num);
    if(num==1){
        post* temp = (post*)malloc(sizeof(post));
    post* save = (post*)malloc(sizeof(post));
    temp = head_post;
        head_post = temp->next_post;
        save = head_post;
        
        while(save!=NULL){
            save->post_num-=1;
            save = save->next_post;
        }
        *(temp->post_id->post_number)-=1;
        free(temp);

    }
    else{
       fdelete(current_user,head_post,num);}
        printf("your post has been succesfully deleted\n");
        free(action);
        break;}
    
    
    case 6:{
        if (current_user==NULL){
            printf("you have to login first\n");
            free(action);
            break;}
        printf("your status and information: \n");
        finfo(current_user,head,head_post);
        free(action);
        break;}


    case 7:{
        a=0;x=1;
        char* name = (char*)malloc(1);
        printf("who are you looking for?\n");
        while (true){char character;
        scanf("%c",&character);
        if(character=='\n'){
            name[x-1]='\0';
            break;}
        name[a]=character;
        a+=1;
        x+=1;
        name = (char*)realloc(name,x);
        name[x-1] = '\0';
       }
       ffind_user(name,head,head_post);
       free(action);
        break;}


    default:{
        printf("your intended action is undifined. try again!\n");
        break;}
    }/*for the switch case*/
    /*start of the FILE*/
    FILE* ptr = fopen("accounts.txt","w");
    user* temp = (user*)malloc(sizeof(user));
    temp = head;
    while(temp!=NULL){
    fprintf(ptr,"name: %s   password: %s  number of posts: %d\n",temp->username,temp->user_password,*(temp->post_number));
    temp = temp->next;}
    fclose(ptr);
    free(temp);
    FILE* ptr_post = fopen("post.txt","w");
    post* temp_post = (post*)malloc(sizeof(post));
    temp_post = head_post;
    while(temp_post!=NULL){
        fprintf(ptr_post,"content: %s   author: %s   likes: %d\n",temp_post->post_content,temp_post->post_id->username,*(temp_post->like_num));
        temp_post= temp_post->next_post;}
    fclose(ptr_post);
    free(temp_post);
    /************/
    }/*for the global while*/
    }/*for the main*/

    