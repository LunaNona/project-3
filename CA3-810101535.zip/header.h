#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define true 1
#define false 0
typedef struct smuser{
    char* username;
    char* user_password;
    int* post_number;
    struct smuser* next;
}user;

typedef struct post{
    user* post_id;/*the person who writes it*/
    char* post_content;
    int* like_num;
    int post_num;/*the number of the posts*/
    struct post* next_post;
}post;

typedef struct like_user{
    char* person;
    int like_num;
    struct like_user* next;
}like_user;


int user_action(char* action);
user* fsignup(char* name,char* password,user* head);/*adds the new user to the head of the linked list*/
user* flogin(char* name,char* password,user* head,user* current_user);
void finfo(user* current_user,user* head,post* head_post);
user* flogout(user* current_user);
void ffind_user(char* name,user* head,post* head_post);
post* fpost(user* current_user,post* head_post,char* content);
void fdelete(user* current_user,post* head_post,int num);
int* flike(post* head_post,char* name,int num);
like_user* flike_user(like_user* head_like, char* name, int num);/*saving the person that is liking the post so that they cant do it twice*/


int user_action(char* action){
    if (strcmp(action,"signup")==0)
        return 0;
    else if (strcmp(action,"login")==0)
        return 1;
    else if (strcmp(action,"post")==0)
        return 2;
    else if (strcmp(action,"like")==0)
        return 3;
    else if (strcmp(action,"logout")==0)
        return 4;
    else if (strcmp(action,"delete")==0)
        return 5;
    else if (strcmp(action,"info")==0)
        return 6;
    else if (strcmp(action,"find_user")==0)
        return 7;
    else
        return 8;}


    like_user* flike_user(like_user* head_like, char* name, int num){/*saving the person that is liking the post so that they cant do it twice*/
    like_user* temp = (like_user*)malloc(sizeof(like_user));
    like_user* save = (like_user*)malloc(sizeof(like_user));
     
     temp->person = name;
    (temp->like_num) = num;
    temp->next = NULL;
    if(head_like==NULL){
    return temp;}
    save = temp;
    temp = head_like;
    while(temp!=NULL){
    if(strcmp(temp->person,name)==0 && ((temp->like_num)==num)){
        return NULL;}
    temp = temp->next;}
    save->next = head_like->next;
    head_like->next = save;
    return head_like;}


user* fsignup(char* name,char* password,user* head){/*adds the new user to the start of the linked list*/
    user* temp=(user*)malloc(sizeof(user));
    temp->username = name;
    temp->user_password = password;
    temp->post_number =(int*)calloc(4,sizeof(int*)); 
    *(temp->post_number) = 0;
    temp->next=NULL;
    if(head!=NULL) /*not that neccesery to be here*/
        temp->next = head;
    head = temp;
    return head;}

    user* flogin(char* name,char* password,user* head,user* current_user){
    user* temp=(user*)malloc(sizeof(user));
    temp = head;
    while (temp != NULL){
        if(strcmp(temp->username,name)==0 && strcmp(temp->user_password,password)==0){
            current_user=temp;
            printf("you are logged in now %s :)\n",current_user->username);
            return current_user;}
        temp = temp->next;}
        printf("this user doesnt exist or maybe you wrote the name or password wrong!\n");
        return NULL;
    }

    void finfo(user* current_user,user* head,post* head_post){
    post* temp = (post*)malloc(sizeof(post));
    temp = head_post;
    if(current_user!=NULL){
        printf("name: %s\npassword: %s \n",current_user->username,current_user->user_password);
        while (temp!=NULL){
            if(strcmp(current_user->username,(temp->post_id)->username)==0){
                printf("%d) %s   likes:%d\n",(temp->post_num),temp->post_content,*(temp->like_num));
                }
            temp = temp->next_post;}
        return;}
    else
        printf("first you have to login.\n");
}

post* fpost(user* current_user,post* head_post,char* content){/*adds posts to the end of the posts linked list*/
    post* temp = (post*)malloc(sizeof(post));
    post* end = (post*)malloc(sizeof(post));
    end->post_id = current_user;
    *((end->post_id)->post_number)+=1;    
    end->post_content = content;
    end->like_num = (int*)calloc(1,sizeof(end->like_num));
    *(end->like_num) = 0;
    (end->post_num) = *(end->post_id->post_number);
    end->next_post = NULL;
    temp = head_post;
    while(true){
    if(head_post==NULL){
        temp = end;
        head_post=temp;
        return head_post;}

    if(temp->next_post==NULL){
        temp->next_post = end;
        return head_post;}
    temp = temp->next_post;   
}
}

user* flogout(user* current_user){
    current_user = NULL;
    return current_user;}

void ffind_user(char* name,user* head,post* head_post){
    user* temp=(user*)malloc(sizeof(user));
    temp = head ;
    while (temp!=NULL){
        if(strcmp(name,temp->username)==0){
            printf("name: %s\n",temp->username);
             post* temp_post = (post*)malloc(sizeof(post));
            /*while for printing the posts and their likes and their id's*/
            temp_post = head_post;
            while(temp_post !=NULL ){
                if(strcmp(temp_post->post_id->username,name)==0){
                      if(temp_post->like_num==NULL){
                        printf("%d)%s   %d likes\n",(temp_post->post_num),(temp_post->post_content),(temp_post->like_num));}
                      else{
                        printf("%d)%s   %d likes\n",(temp_post->post_num),(temp_post->post_content),*(temp_post->like_num));}
                }
                temp_post = temp_post->next_post;}
            return;}
        temp = temp->next;}
    printf("there is no such user with the name %s\n",name);}


    int* flike(post* head_post,char* name,int num){
    post* temp = (post*)malloc(sizeof(post));
    temp = head_post;
    
    while(temp!=NULL){
        if(strcmp(name,(temp->post_id)->username)==0 && (temp->post_num)==num){
            if(temp->like_num==NULL){
                temp->like_num = (int*)malloc(sizeof(int));
                *temp->like_num = 0;}
            *temp->like_num+=1;
            printf("You liked a post\n");
            return temp->like_num;}
        temp = temp->next_post;}
    printf("this post doesnt exist!\n");
    }

    


void fdelete(user* current_user,post* head_post,int num){
    post* temp = (post*)malloc(sizeof(post));
    post* save = (post*)malloc(sizeof(post));
    temp = head_post;
    // if(num==1){
        
    //     return;
    // }
    while(temp!=NULL){
        if (temp->post_id==current_user && temp->post_num==num){
            if (temp->next_post != NULL){
                temp = temp->next_post;
            }
            else{
                temp=NULL;
            }
            save->next_post = temp;
            *(save->post_id->post_number)-=1;
            //free(temp);
        temp = save->next_post;
        while(temp!=NULL){
            temp->post_num-=1;
            temp = temp->next_post;}
            return;
        }
        else{
            save = temp;
            temp = temp->next_post;
        }
    }
}

